#include "ordenacao.hpp"

/* TODO: Implementar função */
bool ordenado(int a[],  unsigned int t){
    return false;
}

/* TODO: Implementar função */
void selecao(int a[], unsigned int t){
}

/* TODO: Implementar função */
void insercao(int a[], unsigned int t){
}

/* TODO: Implementar função */
void merge_sort(int a[], unsigned int t);
